awk "NR==$(((`cat textfile.txt | wc -l`+1) / 2))" textfile.txt
